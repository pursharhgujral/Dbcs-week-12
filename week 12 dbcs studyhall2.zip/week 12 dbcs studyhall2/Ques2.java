package linking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Ques2 {
	public static void main(String[] args) throws Exception {
		String url = "jdbc:mysql://localhost:3306/study";
		String uName = "root";
		String pass = "309919";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, uName, pass);
		Statement st = con.createStatement();
		st = con.createStatement();
		String query = "Insert Into employee values (001,'Pursharth', 'Gujral', 90000, 50, 'pursharthgujral@gmail.com', 'Yamunanager')";
		st.executeUpdate(query);
		query = "Insert Into employee values (002,'Priya', 'Malhotra', 10000, 30, 'kanjilal@gmail.com', 'Chandigarh')";
		st.executeUpdate(query);
		query = "Insert Into employee values (004,'Sawan', 'Verma', 70000, 20, 'dhabbaji@gmail.com', 'Delhi')";
		st.executeUpdate(query);
		query = "Insert Into employee values (005,'Nikhil', 'Singh', 100000, 50, 'nikhil@gmail.com', 'Mumbai')";
		st.executeUpdate(query);
		

		st.close();
		con.close();
	}
}
